#pragma once

/**
 * Represents a generated Island which can be visualized
 */
class Island {

};
