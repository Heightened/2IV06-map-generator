# 2IV06-map-generator

## Dependencies

* wxWidgets (including wx-config)
* OpenGL
* Glew
* glm

## License

This project includes GNU LGPL code.
See the `src/vendor/` directory for details.
